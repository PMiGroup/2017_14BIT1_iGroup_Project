<?php
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<link href="https://bootswatch.com/readable/bootstrap.min.css" rel="stylesheet"></link>
<html>
<head>
<title>Online Quiz - Quiz List</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="quiz.css" rel="stylesheet" type="text/css">
</head>
<body>
<?php
include("header.php");
include("database.php");
echo "<div class='container'>";
echo "<h1 class='page-header'>Quiz Selection</h1>";
$rs=mysql_query("select * from mst_subject");
echo "<div class='col-lg-6 col-lg-offset-4'>";
while($row=mysql_fetch_row($rs))
{
	echo "<h3><a href=showtest.php?subid=$row[0]>$row[1]</a></h3>";
}
echo "</div></div></div>";
?>
</body>
</html>
