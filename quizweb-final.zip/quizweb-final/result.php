<?php
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Online Quiz  - Result </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="https://bootswatch.com/readable/bootstrap.min.css" rel="stylesheet"></link>
<link href="quiz.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php
include("header.php");
include("database.php");
extract($_SESSION);
$rs=mysql_query("select t.test_name,t.total_que,r.test_date,r.score from mst_test t, mst_result r where
t.test_id=r.test_id and r.login='$login'",$cn) or die(mysql_error());
echo '<div class="container">';
echo '<div class="row">';

echo "<h1 class='page-header'> Result </h1>";
if(mysql_num_rows($rs)<1)
{
	echo "<br><br><h1 class=head1> You have not given any quiz</h1>";
	exit;
}
echo "<table class='table' border=1 align=center><tr ><td width=300><h3>Test Name </h3><td> <h3>Total</h3><br><h3> Question</h3> <td> <h3>Score</h3>";
while($row=mysql_fetch_row($rs))
{
echo "<tr class=style8><td><h3>$row[0] </h3><td align=center><h3> $row[1] </h3><td align=center><h3> $row[3]</h3>";
}
echo "</table>";
echo "</div></div>"
?>
</body>
</html>
