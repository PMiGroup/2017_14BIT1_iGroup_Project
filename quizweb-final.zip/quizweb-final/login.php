<?php
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Welcome to PM quiz </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<link href="https://bootswatch.com/readable/bootstrap.min.css" rel="stylesheet"></link>
</head>

<body>
<?php
include("header.php");
include("database.php");
extract($_POST);

if(isset($submit))
{
	$rs=mysql_query("select * from mst_user where login='$loginid' and pass='$pass'");
	if(mysql_num_rows($rs)<1)
	{
		$found="N";
	}
	else
	{
		$_SESSION[login]=$loginid;
	}
}
if (isset($_SESSION[login]))
{
		echo "<div class='container'> 
			<div class='row'> <h1 class='page-header'>Welcome to Project management quiz</h1></div>
			";
		echo "<div class'row'>";
		echo "<div class='col-lg-3 col-lg-offset-5'>";
		echo "<a href='sublist.php' class='btn btn-default'>Subject for Quiz </a>";
		echo "<a href='result.php' class='btn btn-default'>Result </a>";
		echo "</div>"; //div col
		echo "</div>"; // div row
		echo"</div>";//div container
//   </tr>
//   <tr>
//     <td height="58" valign="bottom"><img src="image/DEGREE.JPG" width="43" height="43" align="absmiddle"></td>
//     <td valign="bottom"> <a href="result.php" class="style4">Result </a></td>
//   </tr>
// </table>';

		exit;


}


?>
<div class="container">
	<div class="row">
		<h1 class="page-header">Login</h1>
		<div class="col-lg-5 col-lg-offset-4">
      	<form name="form1" method="post" action="">
          <div class="form-group">
            <label for="exampleInputUsername">Username</label>
            <input type="text" class="form-control" id="exampleInputUsername" placeholder="Username" name="loginid">
          </div>

		  <div class="form-group">
          <label for="exampleInputPassword1">Password</label>
          <input type="password" class="form-control" id="pass" placeholder="Password" name="pass">
          </div>  
		  	<span class="errors">
				<?php
				if(isset($found))
				{
						echo "Invalid Username or Password";
					}
				?>
				<div><td colspan=2 align="center" class="errors">
				</br>
			
			<div class="row">
				<div class="col-lg-6">
					<input class="btn btn-default" name="submit" type="submit" id="submit" value="Login">
					<a href="signup.php" class="btn btn-default">Sign up</a>
				</div>
			</div> 

			</span>

		</form>
	</div>
</div>

</div>
</body>
</html>