<?php
    include("header.php");
    require("../connection.php");
?>

<!DOCTYPE html>
<html lang="\en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
        <div class="display">
            <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">

            </div>

            <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                <form method="POST" class="form-horizontal" role="form" action="edit-questions-ajax.php?que_id="<?php echo $_GET['que_id']?>">
                        <div class="form-group">
                            <legend>Edit Knowledge Areas</legend>
                        </div>

                        <?php
                            if(isset($_GET['que_id'])) {
                                $que_id = $_GET['que_id'];
                                $getselect = mysqli_query($conn, "SELECT * FROM mst_question WHERE que_id='".$que_id."'") or die(mysql_error());
                                while($row=mysqli_fetch_row($getselect)) {
                                    echo "<div class='form-group'>
                                            <span class='label'>Question ID</span>
                                            <input class='form-control' placeholder='Enter questionid' type='text' name='que_id' value='".$row[0]."'>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class='label'>Test ID</span>
                                            <input class='form-control' placeholder='Enter testid' type='text' name='test_id' value='".$row[1]."' que_id='test_id'>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class='label'>Question Desc</span>
                                            <input class='form-control' placeholder='Enter quedesc' type='text' name='que_desc' value='".$row[2]."' que_id='que_desc'>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class='label'>Answer1</span>
                                            <input class='form-control' placeholder='Enter ans1' type='text' name='ans1' value='".$row[3]."' que_id='ans1'>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class='label'>Answer2</span>
                                            <input class='form-control' placeholder='Enter ans2' type='text' name='ans2' value='".$row[4]."' que_id='ans2'>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class='label'>Answer3</span>
                                            <input class='form-control' placeholder='Enter ans3' type='text' name='ans3' value='".$row[5]."' que_id='ans3'>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class='label'>Answer4</span>
                                            <input class='form-control' placeholder='Enter ans4' type='text' name='ans4' value='".$row[6]."' que_id='ans4'>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class='label'>True answer</span>
                                              <input class='form-control' placeholder='Enter true_ans' type='text' name='true_ans' value='".$row[7]."' que_id='true_ans'>
                                        </div>";
										
							echo "<p><input type='submit' value='Finish Editing'/></p>";
                                }
                            }
							//echo $que_id;
                            echo"<div class='form-group'>
                                    <span><a href='login.php' class='btn btn-default'>BACK</a></span>
                                </div>";
                        ?>



                </form>
            </div>

            <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">

            </div>
        </div>
    </body>
</html>

<script>
    $(document).ready(function () {
        $("#edit-info").click(function() {
            $.post("edit-info-ajax.php",
            {
                id:$("#que_id").val(),
                test id: $("#test_id").val(),
                question desc: $("#que_desc").val(),
                answer1: $("#ans1").val(),
                answer2: $("#ans2").val(),
                answer3: $("#ans3").val(),
                answer4: $("#ans4").val(),
                true_ans: $("#true_ans").val()

            },
            function(data, status) {
                if(status=="success")
                {
                    alert("UPDATE SUCCESSFULLY!!!")
                }
	        });
        });
    });
</script>
