-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2017 at 07:49 AM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `igroup`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `username` text COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ID`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Image` text COLLATE utf8_unicode_ci NOT NULL,
  `Initiating` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Planning` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Executing` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Mac` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Closing` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Description` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `ID` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`Name`, `Image`, `Initiating`, `Planning`, `Executing`, `Mac`, `Closing`, `Description`, `ID`) VALUES
('Project Integration Management', '1.jpg', 'Develop Project Charter', 'Develop PM Plan', 'Direct and Mangement Project Work', 'Monitor and Control Project Work, Perform integrated Change Control', 'Close Project or Phase', 'This is covered first in the PMBOK® Guide, but it’s about bringing together everything you know so that you are managing your project holistically and not in individual process chunks. Because of that, it’s easier to study this knowledge area last. Skip this section of the book and come back to it later!', 7),
('Project Scope Management', '2.png', '', 'Plan Scope Management, Collect Requirements,Define Scope, Create WBS', '', 'Validate Scope, Control Scope', '', '‘Scope’ is the way to define what your project will deliver. Scope management is all about making sure that everyone is clear about what the project is for and what it includes. It covers collecting requirements and preparing the work breakdown structure.', 8),
('Project Time Management', '3.png', '', 'Plan Schedule Management, Define Activities, Sequence Activities, Estimate Activities Resources, Estimate Activity Duration, Develop Schedule', '', 'Control Schedule', '', 'Project time management isn’t about being personally more effective. It relates to how you manage the time people are spending on their project tasks, and how long the project takes overall. This knowledge area helps you understand the activities in the project, the sequence of those activities, and how long they are going to take. It’s also where you prepare your project schedule.', 9),
('Project Cost Management', '4.jpg', '', 'Plan Cost Management, Estimate Costs, Determine Budget', '', 'Control Costs', '', 'Cost management is, as you’d expect, all about handling the project’s finances. The big activity in this knowledge area is preparing your budget which includes working out how much each task is going to cost and then determining your project’s overall budget forecast. And, of course, it covers tracking the project’s expenditure against that budget and making sure that you are still on track not to overspend.', 10),
('Project Quality Management', '5.jpg', '', 'Plan quality management', 'Perform quality assurance', 'Control quality', '', 'Project quality management is quite a small knowledge area, as it only covers three processes. This area is where you’ll learn about and set up the quality control and quality management activities on your project so that you can be confident the result will meet your customers’ expectations.', 11),
('Project Human Resource Management', '6.jpg', '', 'Plan Human Resource management', 'Acquire project team, Develop project team, Manage project team', '', '', 'Project human resource management relates to how you run your project team. First, you have to understand what resources you need to be able to complete your project, then you put your team together. After that, it’s all about managing the people on the team including giving them extra skills to do their jobs, if they need it, and learning how to motivate your team.', 12),
('Project Communications Management', '7.jpg', '', 'Plan communication management', 'Manage communications', 'Control Communication', '', 'Given that a project manager’s job is often said to be about 80% communication, this is another small knowledge area. The three processes are planning, managing and controlling project communications. It’s here that you’ll write your communications plan for the project and monitor all the incoming and outgoing communications. There are strong links with human resource management and stakeholder management too, even if these aren’t explicit as I think they should be in the PMBOK® Guide.', 13),
('Project Risk Management', '8.jpg', '', 'Plan risk management, Identify risks, Perform qualitative risk analysis, Perform quantiative risk analysis, Plan risk responses', '', 'Control risks', '', 'The first step in project risk management is planning your risk management work, and then you quickly move on to identifying risks and understanding how to assess risks on your project. There is a lot of detail in this knowledge area, specifically around how you perform quantitative and qualitative risk assessments. Risk management isn’t a one-off activity, though, and this knowledge area also covers controlling your project risks going forward through the project life cycle.', 14);

-- --------------------------------------------------------

--
-- Table structure for table `questionaire`
--

CREATE TABLE `questionaire` (
  `ID` int(100) NOT NULL,
  `Question` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `AnswerA` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `AnswerB` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `AnswerC` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `AnswerD` varchar(1000) COLLATE utf8_unicode_ci NOT NULL,
  `CorrectAnswer` varchar(1000) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `questionaire`
--

INSERT INTO `questionaire` (`ID`, `Question`, `AnswerA`, `AnswerB`, `AnswerC`, `AnswerD`, `CorrectAnswer`) VALUES
(1, 'What is a stakeholder?', 'The person responsible for preparing the project budget.', 'An organization that’s hired to perform risk analysis.', 'A person or organization that is not actively involved in the project, or whose interests will not be affected by execution or completion of the project.', 'A person or organization that is actively involved in the project, or whose interests may be positively or negatively affected by execution or completion of the project.', 'a'),
(2, 'A project charter:', 'Lists the names and roles of all project team members.', 'Is most often reviewed when documenting lessons learned.', 'Formally authorizes the existence of a project.', 'Is used to document change requests.', 'b'),
(3, 'Which subsidiary plan is not a part of the project management plan?', 'human resource management plan', 'communications management plan', 'risk management plan', 'baseline management plan', 'c'),
(4, 'When does a project reach its end?', 'When the project objectives have been achieved.', 'When the project is terminated because its objectives will not or cannot be met.', 'When the need for the project no longer exists.', 'For any of the reasons above.', 'd'),
(5, 'Which of the following is not a project constraint?', 'Schedule', 'Stakeholder', 'Budget', 'Quality', 'a'),
(6, 'Organizational project management is a strategy execution framework that utilizes which of the following?', 'project management', 'program management', 'portfolio management', 'all of the above', 'b'),
(7, 'Which answer best describes the PMBOK® Guide?', 'It contains the standard for managing most projects most of the time across many types of industries.', 'It contains step-by-step instructions for managing all projects.', 'It contains the standard for how project managers must conduct themselves.', 'It ensures project success.', 'c'),
(8, 'In the classic functional organization, the project manager’s authority is', 'high.', 'little or none.', 'moderate to high.', 'moderate.', 'd'),
(9, 'Which of the following best describe organizational process assets?', 'buildings and equipment owned by the performing organization', 'reasons that most projects encounter risk', 'items that must be estimated before the schedule is developed', 'plans, processes, policies, procedures, and knowledge bases specific to and used by the performing organization', 'a'),
(10, 'Project management offices (PMO) often serve which function?', 'They provide human resource support functions.', 'They provide project management certification exams.', 'They provide accounting and budgetary support functions.', 'They provide project management support functions.', 'c');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indexes for table `questionaire`
--
ALTER TABLE `questionaire`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
