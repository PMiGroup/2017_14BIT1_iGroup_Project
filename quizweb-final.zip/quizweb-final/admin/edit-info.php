<?php
    include("header.php"); 
    require("connection.php");    
?>  

<!DOCTYPE html>
<html lang="\en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
        <div class="display">
            <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                
            </div>

            <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">                
                <form method="POST" class="form-horizontal" role="form">
                        <div class="form-group">
                            <legend>Edit Knowledge Areas</legend>
                        </div>

                        <?php
                            if(isset($_GET['ID'])) {
                                $id = $_GET['ID'];
                                $getselect = mysqli_query($conn, "SELECT * FROM info WHERE ID='$id'") or die(mysql_error());
                                while($profile = mysqli_fetch_array($getselect)) {
                                    echo "<div class='form-group'>
                                            <span class='label'>Name</span>
                                            <input class='form-control' placeholder='Enter name' type='text' name='name' value='$profile[Name]' id='name'>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class='label'>Image</span>
                                            <img src='./images/$profile[Image]' height='100px' width='150px'>
                                            <input class='form-control' type='file' name='image' value='$profile[Image]' id='img'>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class='label'>Initiating</span>
                                            <input class='form-control' placeholder='Enter initiating' type='text' name='initiating' value='$profile[Initiating]' id='init'>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class='label'>Planning</span>
                                            <input class='form-control' placeholder='Enter planing' type='text' name='planning' value='$profile[Planning]' id='plan'>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class='label'>Executing</span>
                                            <input class='form-control' placeholder='Enter executing' type='text' name='executing' value='$profile[Executing]' id='exec'>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class='label'>Monitoring and Controlling</span>
                                            <input class='form-control' placeholder='Enter Monitoring and Controlling' type='text' name='mac' value='$profile[Mac]' id='mac'>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class='label'>Closing</span>
                                            <input class='form-control' placeholder='Enter closing' type='text' name='closing' value='$profile[Closing]' id='close'>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class='label'>Description</span>
                                            <textarea class='form-control' placeholder='Enter description' rows='10' cols='10' type='text' name='description' id='description'>$profile[Description]</textarea>
                                        </div>";       
                                }
                            }
                            echo"<div class='form-group'>
                                    <button href='info.php' class='btn btn-primary edit-info pull-right' id='edit-info' value='$id'>UPDATE</button>
                                    <span><a href='info.php' class='btn btn-default'>BACK</a></span>
                                </div>"
                        ?>

                        
                    
                </form>                
            </div>

            <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                
            </div>
        </div>
    </body>
</html>

<script>
    $(document).ready(function () {
        $("#edit-info").click(function() {    
            $.post("edit-info-ajax.php", 
            {
                id:$("#edit-info").val(),
                name: $("#name").val(), 
                image: $("#img").val().replace(/C:\\fakepath\\/i, ''),
                initiating: $("#init").val(), 
                planning: $("#plan").val(), 
                executing: $("#exec").val(), 
                mac: $("#mac").val(), 
                closing: $("#close").val(), 
                description: $("#description").val()
            }, 
            function(data, status) {
                if(status=="success")
                {
                    alert("UPDATE SUCCESSFULLY!!!")
                }
	        });
        });
    });
</script>  