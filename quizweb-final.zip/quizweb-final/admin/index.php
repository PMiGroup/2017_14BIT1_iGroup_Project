<?php
session_start()
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
<title>Administrative Login - Online Exam</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="../quiz.css" rel="stylesheet" type="text/css">
<link href="https://bootswatch.com/readable/bootstrap.min.css" rel="stylesheet"></link>
</head>

<body>
<?php
include("header.php");
?>
<div class="container">
  <div class="row">
      
<h1 class="page-header">Adminstrative Login </h1>
  <form class="form-group" name="form1" method="post" action="login.php">
        <div class="col-lg-4 col-lg-offset-4">
          <h1>Username</h1>
        <input name="loginid" type="text" id="loginid"></div>
        </div>

        <div class="col-lg-4 col-lg-offset-4">
          <h1>Password</h1>
        <input name="pass" type="password" id="pass">
       
      </div>
      
      <div class="col-lg-4 col-lg-offset-4">
          <input class="btn btn-default" name="submit" type="submit" id="submit" value="Login">
      </div>
       
  </form>
  </div>
</div>

</body>
</html>
