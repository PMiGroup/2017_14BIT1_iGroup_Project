<?php
    ob_start();
    require("connection.php");
    if(isset($_GET['que_id']) != "") {
        $delete = $_GET['que_id'];
        $delete = mysqli_query($conn, "DELETE FROM mst_question WHERE que_id='$delete'");
        if($delete) {
            header("Location: delete.php");
        }
        else {
            echo mysql_error();
        }
    }
    ob_end_flush();
    //require 'delete.php';
?>
