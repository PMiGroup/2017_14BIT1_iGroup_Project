<?php
    ob_start();
    require("connection.php");
    if(isset($_GET['ID']) != "") {
        $delete = $_GET['ID'];
        $delete = mysqli_query($conn, "DELETE FROM info WHERE ID='$delete'");
        if($delete) {
            header("Location: info.php");
        }
        else {
            echo mysql_error();
        }
    }
    ob_end_flush();
?>