<?php

    require("connection.php");?>
    <?php $result = mysqli_query($conn, 'SELECT * FROM mst_question');
    $num_rows = mysqli_num_rows($result);?>

    <body>
        <div class="container">
            <table cellpadding="15" cellspacing="2" class="table table-hover">
            <tbody>

                <div class="container">
                <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">

                </div>

                <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
                        <tr>
                            <th><strong>Question ID</strong></th>
                            <th><strong>TEST_ID</strong></th>
                            <th><strong>QUESTION_DESC</strong></th>
                            <th><strong>Answer A</strong></th>
                            <th><strong>Answer B</strong></th>
                            <th><strong>Answer C</strong></th>
                            <th><strong>Answer D</strong></th>
                            <th><strong>Correct Answer</strong></th>
                            <th></th>
                            <th></th>
                        </tr>
                        <?php for ($i = 1; $i <= $num_rows; $i++) { ?>
                            <?php while ($ques = mysqli_fetch_object($result)) { ?>
                                <tr>
                                    <td><?php echo $ques->que_id; ?></td>
                                    <td><?php echo $ques->test_id; ?></td>
                                    <td><?php echo $ques->que_desc; ?></td>
                                    <td><?php echo $ques->ans1; ?></td>
                                    <td><?php echo $ques->ans2; ?></td>
                                    <td><?php echo $ques->ans3; ?></td>
                                    <td><?php echo $ques->ans4; ?></td>
                                    <td><?php echo $ques->true_ans; ?></td>
									<td><span><a href="edit-questions.php?que_id=<?php echo $ques->que_id; ?>" class="btn btn-danger glyphicon glyphicon-remove-circle">Edit</a></span></td>
                                    <td><span><a href="delete-questions.php?que_id=<?php echo $ques->que_id; ?>" class="btn btn-danger glyphicon glyphicon-remove-circle">Delete</a></span></td>
                                </tr>
                            <?php } ?>
                        <?php } ?>
                    </form>
                </div>
                        <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">

                        </div>
                    </div>
                </tbody>
            </table>
        </div>

						<div><a href="login.php">Go back</a></div>
    </body>
</html>
