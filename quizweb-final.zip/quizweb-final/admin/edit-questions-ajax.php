<?php
    ob_start();
    require("connection.php");
        if((isset($_GET['que_id']) != "")) {
            $que_id=$_POST['que_id'];
            $test_id = $_POST['test_id'];
            $que_desc= $_POST['que_desc'];
            $ans1 = $_POST['ans1'];
            $ans2 = $_POST['ans2'];
            $ans3 = $_POST['ans3'];
            $ans4 = $_POST['ans4'];
            $true_ans = $_POST['true_ans'];


            $updated ="UPDATE mst_question SET que_id='$que_id', test_id='$test_id', que_desc='$que_desc', ans1='$ans1', ans2='$ans2', ans3='$ans3', ans4='$ans4', true_ans='$true_ans' WHERE que_id='$que_id'";
			$success=mysqli_query($conn, $updated);
			//echo $updated;
			if($success) {
            header("Location: delete.php");
			}
			else {
				echo mysql_error();
			}            
        }

    ob_end_flush();
?>
