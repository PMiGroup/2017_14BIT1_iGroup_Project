<?php 
    require("connection.php");
    // $id = $_POST["ID"];
    $question = $_POST["question"];
    $answera = $_POST["answera"];
    $answerb = $_POST["answerb"];
    $answerc = $_POST["answerc"];
    $answerd = $_POST["answerd"];
    $correctanswer = $_POST["correctanswer"];

    $addquestions_query = "INSERT INTO questionaire (Question, AnswerA, AnswerB, AnswerC, AnswerD, CorrectAnswer) VALUES ('$question', '$answera', '$answerb', '$answerc', '$answerd', '$correctanswer')";

    mysqli_query($conn, $addquestions_query);
?>