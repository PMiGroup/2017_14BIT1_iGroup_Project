<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>iGroup</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link href="index.css" rel="stylesheet" type="text/css">
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="50">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#myPage">iGroup</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#myPage">HOME</a></li>
        <li><a href="#igroup">iGROUP</a></li>
        <li><a href="#update">UPDATES</a></li>
		<li><a href="infoview.php">Articles</a></li>
        <li><a href="#info">INFO</a></li>
        <li><a href="login.php">SIGN IN</a></li>
        <li><a href="#"><span class="glyphicon glyphicon-search"></span></a></li>
      </ul>
    </div>
  </div>
</nav>

<div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="http://cognitio.biz/wp-content/uploads/2017/01/pmbok.png" alt="vinh" width="1200" height="1000">

      </div>

      <div class="item">
        <img src="https://quotefancy.com/media/wallpaper/3840x2160/15447-Lily-Tomlin-Quote-The-road-to-success-is-always-under-construction.jpg" alt="vinh" width="1200" height="700">

      </div>

      <div class="item">
        <img src="http://www.isindexing.com/isi/itemimages/1490239994.jpg" alt="vinh" width="1200" height="700">

      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
</div>

<div id="igroup" class="container text-center">
  <h1 class="page-header">PROJECT MANAGEMENT</h1>
  <h1><em>We love this subject!</em></h1>
  <h2>We have created a online quiz website in order to help everyone can improve their knowledge as well as remembering what they learnt.</h2>
  <br>
  <div class="row">

    <div class="container">
       <div class="col-sm-2">
      <p class="text-center"><strong>Khiêm</strong></p><br>
      <a href="#demo" data-toggle="collapse">
        <img src="https://rlv.zcache.com/mini_superman_flying_statuette-r548c1627559d4552b3437353c275f9bb_x7saw_8byvr_324.jpg" class="img-circle person" alt="Random Name" width="255" height="255">
      </a>
      <div id="demo" class="collapse">
        <p>Leader</p>
        <p>Loves listening to music</p>
        <p>Member since 2017</p>
      </div>
    </div>

    <div class="col-sm-2">
      <p class="text-center"><strong>Huy</strong></p><br>
      <a href="#demo2" data-toggle="collapse">
        <img src="https://s-media-cache-ak0.pinimg.com/originals/bb/81/88/bb818897d16a9f54c2215e7ef2051e88.jpg" class="img-circle person" alt="Random Name" width="255" height="255">
      </a>
      <div id="demo2" class="collapse">
        <p>Tester</p>
        <p>Loves reading books</p>
        <p>Member since 2017</p>
      </div>
    </div>

    <div class="col-sm-2">
      <p class="text-center"><strong>Vinh</strong></p><br>
      <a href="#demo3" data-toggle="collapse">
        <img src="http://orig00.deviantart.net/0cc2/f/2013/333/4/e/chibi_thor___by_chickenzpunk-d6w20wq.jpg" class="img-circle person" alt="Random Name" width="255" height="255">
      </a>
      <div id="demo3" class="collapse">
        <p>Developer</p>
        <p>Loves playing games</p>
        <p>Member since 2017</p>
      </div>
    </div>

    <div class="col-sm-2">
      <p class="text-center"><strong>Đạt</strong></p><br>
      <a href="#demo4" data-toggle="collapse">
        <img src="https://s-media-cache-ak0.pinimg.com/736x/5b/ee/a0/5beea0f2e915f3a6170dfac705897560--super-hero-shirts-venom.jpg" class="img-circle person" alt="Random Name" width="255" height="255">
      </a>
      <div id="demo4" class="collapse">
        <p>Developer</p>
        <p>Loves playing pokemon</p>
        <p>Member since 2017</p>
      </div>
    </div>

    <div class="col-sm-2">
      <p class="text-center"><strong>Thông</strong></p><br>
      <a href="#demo5" data-toggle="collapse">
        <img src="https://s-media-cache-ak0.pinimg.com/736x/66/3e/1f/663e1f9712aff6a08c4f74c507134cf7--moon-knight-black-panthers.jpg" class="img-circle person" alt="Random Name" width="255" height="255">
      </a>
      <div id="demo5" class="collapse">
        <p>Tester</p>
        <p>Loves watching TV</p>
        <p>Member since 2017</p>
      </div>
    </div>
    </div>

   

  </div>
</div>

<!-- Container (Update Section) -->
<div id="update" class="bg-1">
  <div class="container">
    <h3 class="text-center">Quiz UPDATES</h3>
    <p class="text-center">we'll help you improve your PM knowledge.<br> Remember to register and join us</p>
    <ul class="list-group">
      <li class="list-group-item">PMBOK <span class="label label-danger">Coming soon!</span></li>
      <li class="list-group-item">PMBOK <span class="label label-danger">Coming soon!</span></li>
      <li class="list-group-item">PMBOK <span class="badge">3</span></li>
    </ul>

    <div class="row text-center">
      <div class="col-sm-4">
        <div class="thumbnail">
          <img src="http://weclipart.com/gimg/E767475E16736AF0/project-management-mind-map-with-business-concept-words_62112796.jpg" alt="Paris" width="400" height="300">
          <p><strong>PMBOK</strong></p>
          <p>Friday 25 August 2017</p>
          <button class="btn" data-toggle="modal" data-target="#myModal"><a href="login.php">Sign in</a></button>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="thumbnail">
          <img src="https://image.slidesharecdn.com/prince2pmbokpresentation-121116045447-phpapp01/95/comparing-prince2-and-the-pmbok-1-638.jpg?cb=1445951631" alt="New York" width="400" height="300">
          <p><strong>PMBOK</strong></p>
          <p>Saturday 17 September 2017</p>
          <button class="btn" data-toggle="modal" data-target="#myModal"><a href="login.php">Sign in</a></button>
        </div>
      </div>
      <div class="col-sm-4">
        <div class="thumbnail">
          <img src="http://img.zanda.com/item/04061490000082/1024x768/A_Guide_to_the_Project_Management_Body_of_Knowledge_Project_Management_Institute_Book.jpg" alt="San Francisco" width="400" height="300">
          <p><strong>PMBOK</strong></p>
          <p>Monday 16 October 2017</p>
          <button class="btn" data-toggle="modal" data-target="#myModal"><a href="login.php">Sign in</a></button>
        </div>
      </div>
    </div>
  </div>

</div>

  <br>
  <div id="info">
   <div class="row text-center">
      <div class="col-lg-12">
        <img src="https://s-media-cache-ak0.pinimg.com/originals/ed/7d/97/ed7d9706b9a6bff7e5849234beda932e.jpg" alt=""  height="100%" width="100%"> 
    </div>
  </div>

<!-- Footer -->
<footer class="text-center">
  <a class="up-arrow" href="#myPage" data-toggle="tooltip" title="TO TOP">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a><br><br>
  <p> Made By iGroup</a></p>
</footer>

<script>
$(document).ready(function(){
  // Initialize Tooltip
  $('[data-toggle="tooltip"]').tooltip();
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();
      // Store hash
      var hash = this.hash;
      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
})
</script>

</body>
</html>
