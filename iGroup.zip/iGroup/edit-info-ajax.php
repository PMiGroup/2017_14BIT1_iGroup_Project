<?php
    require("connection.php");
        if(isset($_POST['id'])) {
            $id=$_POST['id'];
            $name = $_POST['name'];
            $image = $_POST['image'];
            $initiating = $_POST['initiating'];
            $planning = $_POST['planning'];
            $executing = $_POST['executing'];
            $mac = $_POST['mac'];
            $closing = $_POST['closing'];
            $description = $_POST['description'];

            $updated ="UPDATE info SET Name='$name', Image='$image', Initiating='$initiating', Planning='$planning', Executing='$executing', Mac='$mac', Closing='$closing', Description='$description' WHERE ID='$id'";

            mysqli_query($conn, $updated);
        }

?>