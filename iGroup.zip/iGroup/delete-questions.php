<?php
    ob_start();
    require("connection.php");
    if(isset($_GET['ID']) != "") {
        $delete = $_GET['ID'];
        $delete = mysqli_query($conn, "DELETE FROM questionaire WHERE ID='$delete'");
        if($delete) {
            header("Location: questions.php");
        }
        else {
            echo mysql_error();
        }
    }
    ob_end_flush();
?>