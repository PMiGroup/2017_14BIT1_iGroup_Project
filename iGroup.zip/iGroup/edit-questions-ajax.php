<?php
    require("connection.php");
        if(isset($_POST['id'])) {
            $id=$_POST['id'];
            $question = $_POST['question'];
            $answera = $_POST['answera'];
            $answerb = $_POST['answerb'];
            $answerc = $_POST['answerc'];
            $answerd = $_POST['answerd'];
            $correctanswer = $_POST['correctanswer'];            

            $updated = "UPDATE questionaire SET Question='$question', AnswerA='$answera', AnswerB='$answerb', AnswerC='$answerc', AnswerD='$answerd', CorrectAnswer='$correctanswer' WHERE ID='$id'";

            mysqli_query($conn, $updated);
        }

?>