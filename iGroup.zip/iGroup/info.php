<?php
    include("header.php"); 
    require("connection.php");
    
    $result = mysqli_query($conn, 'SELECT * FROM info') or die(mysql_error());
    $num_rows = mysqli_num_rows($result);
    $rows = $num_rows/3;

?>
    <body>        
        <div class="container">
            <table cellpadding="15" cellspacing="2" class="table table-hover">
            <tbody>          

                <div class="container">            
                <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1">
                    
                </div>

                <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">                
                    <form method="POST" class="form-horizontal" role="form">
                        <div class="form-group">
                            <legend>Knowledge Areas</legend>
                        </div>                
                            
                        <div class="form-group">
                            <span><strong>NEW KNOWLEDGE AREA: </strong></span>
                            <span><a href="add-info.php" class="btn btn-info">ADD</a></span>
                        </div>

                        <div class="form-group">
                            <span><strong>QUESTIONS: </strong></span>
                            <span><a href="questions.php" class="btn btn-info">VIEW</a></span>
                        </div>
                                                
                        <tr>
                            <th><strong>Name</strong></th>
                            <th><strong>Image</strong></th>
                            <th><strong>Initiating</strong></th>
                            <th><strong>Planning</strong></th>
                            <th><strong>Executing</strong></th>
                            <th><strong>Monitoring and Controlling</strong></th>
                            <th><strong>Closing</strong></th>
                            <th><strong>Description</strong></th>
                            <th></th>
                            <th></th>
                        </tr>
                        <?php for ($i = 1; $i <= $num_rows; $i++) { ?>
                            <?php while ($info = mysqli_fetch_object($result)) { ?>
                                <tr>
                                    <td><?php echo $info->Name; ?></td>
                                    <td><?php
                                            echo "<img src='./images/$info->Image' height='100px' width=100px'>";
                                        ?></td>
                                    <td><?php echo $info->Initiating; ?></td>
                                    <td><?php echo $info->Planning; ?></td>
                                    <td><?php echo $info->Executing; ?></td>
                                    <td><?php echo $info->Mac; ?></td>
                                    <td><?php echo $info->Closing; ?></td>
                                    <td><?php echo $info->Description; ?></td>
                                    <td><span><a href="edit-info.php?ID=<?php echo $info->ID; ?>" class="btn btn-primary glyphicon glyphicon-edit">Edit</a></span></td>
                                    <td><span><a href="delete-info.php?ID=<?php echo $info->ID; ?>" class="btn btn-danger glyphicon glyphicon-remove-circle">Delete</a></span></td>
                                </tr>
                            <?php } ?>
                        <?php } ?>
                    </form>                
                </div>

                        <div class="col-xs-2 col-sm-2 col-md-2 col-lg-2">
                        
                        </div>            
                    </div> 
                </tbody>
            </table> 
        </div>
        
    </body>
</html>