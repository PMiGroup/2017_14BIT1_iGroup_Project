<?php
    include("header.php"); 
    require("connection.php"); 
?>  

<!DOCTYPE html>
<html lang="\en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
        <div class="display">
            <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                
            </div>

            <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">                
                <form method="POST" class="form-horizontal" role="form">
                        <div class="form-group">
                            <legend>Edit Questions</legend>
                        </div>

                        <?php
                            if(isset($_GET['ID'])) {
                                $id = $_GET['ID'];
                                $getselect = mysqli_query($conn, "SELECT * FROM questionaire WHERE ID='$id'") or die(mysql_error());
                                while($profile = mysqli_fetch_array($getselect)) {
                                    echo "<div class='form-group'>
                                            <span class=' label'></span>
                                            <textarea class='form-control' placeholder='Enter question' rows='10' cols='10' type='text' name='question' id='question'>$profile[Question]</textarea>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class=' label'>Answer A</span>
                                            <textarea class='form-control' placeholder='Enter Answer A' rows='10' cols='10' type='text' name='answera' id='answera'>$profile[AnswerA]</textarea>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class=' label'>Answer B</span>
                                            <textarea class='form-control' placeholder='Enter Answer B' rows='10' cols='10' type='text' name='answerb' id='answerb'>$profile[AnswerB]</textarea>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class=' label'>Answer C</span>
                                            <textarea class='form-control' placeholder='Enter Answer C' rows='10' cols='10' type='text' name='answerc' id='answerc'>$profile[AnswerC]</textarea>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class=' label'>Answer D</span>
                                            <textarea class='form-control' placeholder='Enter Answer D' rows='10' cols='10' type='text' name='answerd' id='answerd'>$profile[AnswerD]</textarea>
                                        </div>";
                                    echo "<div class='form-group'>
                                            <span class='label'>Correct Answer</span>
                                            <input class='form-control' placeholder='Enter correct answer' type='text' name='correctanswer' value='$profile[CorrectAnswer]' id='correctanswer'>
                                        </div>";       
                                }
                            }
                            echo"<div class='form-group'>
                                    <button class='btn btn-primary edit-questions pull-right' id='edit-questions' value='$id'>UPDATE</button>
                                    <span><a href='questions.php' class='btn btn-default'>BACK</a></span>
                                </div>"
                        ?>

                        
                    
                </form>                
            </div>

            <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                
            </div>
        </div>
    </body>
</html>

<script>
    $(document).ready(function () {
        $("#edit-questions").click(function() {    
          
            $.post("edit-questions-ajax.php", 
            {
                id:$("#edit-questions").val(),
                question: $("#question").val(), 
                answera: $("#answera").val(),
                answerb: $("#answerb").val(), 
                answerc: $("#answerc").val(), 
                answerd: $("#answerd").val(),
                correctanswer: $("#correctanswer").val() 
            }, 
            function(data, status) {
                if(status=="success")
                {
                    alert("UPDATE SUCCESSFULLY!!!")
                }
	        });
        });
    });
</script>