<?php 
    include("header.php");
    require("connection.php");
?>
    <body>
        

        <div class="container">            
            <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                
            </div>

            <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">

                <?php
                    $error='';
                    if (isset($_POST['login'])) {
                        $username=$_POST['username'];
                        $password=$_POST['password'];

                        $username = stripslashes($username);
                        $password = stripslashes($password);
                        $username = mysql_real_escape_string($username);
                        $password = mysql_real_escape_string($password);

                        if (empty($_POST['username']) || empty($_POST['password'])) {
                            $error = "Username or Password is invalid";
                        }
                        else {
                            // Define $username and $password
                            

                            $query = mysqli_query($conn, "SELECT * FROM admin WHERE username = '$username' and password = '$password'");
                            $rows = mysql_num_rows($query);
                            if ($rows == 1) {
                                $_SESSION['username']=$username; // Initializing Session
                                header("location: info.php"); // Redirecting To Other Page
                            }
                            else {
                                $error = "Username or Password is invalid";
                            }
                        }
                    }
                ?>

                <form action="info.php" method="POST" class="form-horizontal" role="form">
                        <div class="form-group">
                            <legend>Log In</legend>
                        </div>                
                        <div class="form-group">
                            <span class="label">Username</span>
                            <input class="form-control" placeholder="Enter username" type="text" name="username">
                        </div>
                        <div class="form-group">
                            <span class="label">Password</span>
                            <input class="form-control" placeholder="Enter password" type="pass" name="password">
                        </div>
                        
                        <div class="form-group">
                             <button type="summit" class="btn btn-primary" id="login" name="login">LOG IN</button>
                        </div>
                </form>                
            </div>

            <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                
            </div>
            
        </div>                 
    </body>
</html>