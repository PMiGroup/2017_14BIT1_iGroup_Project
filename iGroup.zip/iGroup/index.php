<?php 
    include("header.php"); 
    $result = mysqli_query($conn, 'SELECT * FROM info') or die(mysql_error());
    $ques = mysqli_query($conn, 'SELECT * FROM questionaire') or die(mysql_error());
    $num_rows = mysqli_num_rows($result);
    $rows = $num_rows/3;
?>
<style>
.morecontent span {
    display: none;
}
.morelink {
    display: block;
}
</style>
<body>
    <div class="container">
        <div class="page-header">

            <h3>
                Learn all about
                <strong>PROJECT MANAGEMENT BOOK OF KNOWLEDGE</strong>
            </h3>
        </div>
        <div>
            <form class="form-inline well well-sm clearfix navbar-form">
                <span class="glyphicon glyphicon-search"></span>
                <input type="text" placeholder="Search..." class="form-control">
                <a href="quiz.php" class="btn btn-warning pull-right">
                    <strong>Start Quiz</strong>
                </a>
            </form>

            <?php while ($info = mysqli_fetch_object($result)) { ?>
            <div class="row">
                <div class="col-sm-12">
                    <div class="well well-sm knowledge-area-well">
                        <div class="row">
                            <div class="col-md-4">
                                <?php
                                    echo "<img src='./images/$info->Image' height='200px' width='375px'>"
                                ?>
                            </div>
                            <div class="col-md-8">
                                <div class="more">
                                    <h4><strong><?php echo $info->Name; ?></strong></h4>
                                    <p><strong>Initiating: </strong>
                                        <?php echo $info->Initiating; ?>
                                    </p>
                                    <p><strong>Planning: </strong>
                                        <?php echo $info->Planning; ?>
                                    </p>
                                    <p><strong>Executing: </strong>
                                        <?php echo $info->Executing; ?>
                                    </p>
                                    <p><strong>Monitoring and Controlling: </strong>
                                        <?php echo $info->Mac; ?>
                                    </p>
                                    <p><strong>Closing: </strong>
                                        <?php echo $info->Closing; ?>
                                    </p>
                                    </span>
                                    <p><strong>Description: </strong>
                                        <?php echo $info->Description; ?>
                                    </p>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </div>

    <!-- <script src="js/app.js"></script>
    <script src="js/controllers/list.js"></script>
    <script src="js/controllers/quiz.js"></script>
    <script src="js/controllers/results.js"></script>
    <script src="js/factories/quizMetrics.js"></script>
    <script src="js/factories/dataservice.js"></script> -->

</body>

</html>

<script>
    $(document).ready(function () {
        var showChar = 100;
        var moretext = "Show less";
        var lesstext = "Show more";

        $('.more').each(function () {
            var content = $(this).html();
            if (content.length > showChar) {
                var c = content.substr(0, showChar);
                console.log(c);
                var h = content.substr(showChar, content.length - showChar);
                console.log(h);
                var html = c + '<span class="moreellipses">' +
                    '</span><span class="morecontent"><span>' + h +
                    '</span><a href="" class="morelink">' + lesstext + '</a></span>';

                $(this).html(html);
            }
        });

        $(".morelink").click(function () {
            if ($(this).hasClass("less")) {
                $(this).removeClass("less");
                $(this).html(lesstext);
            } else {
                $(this).addClass("less");
                $(this).html(moretext);
            }
            $(this).parent().prev().toggle();
            $(this).prev().toggle();
            return false;
        });
    });
</script>

