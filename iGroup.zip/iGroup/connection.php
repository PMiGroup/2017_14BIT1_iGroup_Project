<?php
    $host = "localhost";
    $db = "igroup";
    $user = "root";
    $pass = "";

    $conn = new mysqli($host, $user, $pass, $db);

    if ($conn->connect_errno == 0) {
        //echo "Connected Database!!!";
    } 
    else {
        echo $conn->connect_errno;
    }

    if ($conn->connect_errno) {
        die("Connection failed!!!");
    }

    $conn->set_charset("utf8");
?>
