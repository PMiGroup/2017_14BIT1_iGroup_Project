<?php
	require("connection.php");
	include("header.php");
	$result = mysqli_query($conn, "SELECT * FROM questionaire");
?>

	<body>
		
			<?php while ($quiz = mysqli_fetch_object($result)) { ?>
				
					<div class="container">
						<div class="row"><br>
							<span class="image-position"><a href="https://www.facebook.com/meuix/?ref=settings" target="_blank">
							<img src="https://lh4.googleusercontent.com/fLEIj3iQb7O1FhjOpLFbJtHmsMlLGmLynSWUvAP70qF0HLEBty-FANvwweg7Sv2XqSpzOKNI=w1366-h638"></a>
							</span>
						</div>
						<div class="row"><br><br>
							<div class="col-sm-8 col-sm-offset-2">
								<div class="loader">
									<div class="col-xs-3 col-xs-offset-5">
										<div id="loadbar" style="display: none;">
											<img src="http://schoolsearch.co.ke/systems/img/loader.gif_large.gif" alt="Loading" class="center-block loanParamsLoader"
												style="">
										</div>
									</div>

									<div id="quiz"> 
										<!--Timer-->
										<div class="timer">
											<p id="timer"></p>
											<script>
												$(document).ready(function () {
													var countDownDate = new Date().getTime() / 1000;
													// Update the count down every 1 second
													countDownDate = countDownDate + 10;
													var x = setInterval(function () {
														var now = new Date().getTime() / 1000;
														// Find the distance between now an the count down date
														var distance = countDownDate - now;						
														document.getElementById("timer").innerHTML = parseInt(distance) + "s ";										
														if (distance < 0) {
															clearInterval(x);
															document.getElementById("timer").innerHTML="Time's up";
														}
													}, 1000);
												});
											</script>  
										</div>
										<div class="question">
											<h3><span class="label label-warning" id="qid"><?php echo $quiz->ID; ?></span>
												<span id="question"><?php echo $quiz->Question; ?></span>
											</h3>
										</div>
										<ul>
											<li>
												<input type="radio" class="inputoption" id="f-option" name="selector" value="1">
												<label for="f-option" class="element-animation"><?php echo $quiz->AnswerA; ?></label>
												<div class="check"></div>
											</li>

											<li>
												<input type="radio" class="inputoption" id="s-option" name="selector" value="2">
												<label for="s-option" class="element-animation"><?php echo $quiz->AnswerB; ?></label>
												<div class="check">
													<div class="inside"></div>
												</div>
											</li>

											<li>
												<input type="radio" class="inputoption" id="t-option" name="selector" value="3">
												<label for="t-option" class="element-animation"><?php echo $quiz->AnswerC; ?></label>
												<div class="check">
													<div class="inside"></div>
												</div>
											</li>

											<li>
												<input type="radio" class="inputoption" id="o-option" name="selector" value="4">
												<label for="o-option" class="element-animation"><?php echo $quiz->AnswerD; ?></label>
												<div class="check">
													<div class="inside"></div>
												</div>
											</li>
										</ul>
									</div>
								</div>
								<div class="text-muted">
									<span id="answer"></span>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-8 col-sm-offset-2">
								<div id="result-of-question" class="pulse animated" style="display: none;">
									<span id="totalCorrect" class="pull-right"></span>
									<table class="table table-hover table-responsive">
										<thead>
											<tr>
												<th>Question No.</th>
												<th>Our answer</th>
												<th>Your answer</th>
												<th>Result</th>
											</tr>
										</thead>
										<tbody id="quizResult"></tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				<?php } ?>		
	</body>
	</html>

	<script>
		$(function () {
			var loading = $('#loadbar').hide();
			$(document)
			.ajaxStart(function () {
				loading.show();
			}).ajaxStop(function () {
				loading.hide();
			});

			var questionNo = 0;
    		var correctCount = 0;
		});
	</script>