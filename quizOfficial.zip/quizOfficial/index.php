<?php
$cn=mysqli_connect("localhost","root","","questionaire");
mysqli_set_charset($cn,"utf8");
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$number_of_quiz=mysqli_query($cn,"select count(ID )from questionaire");
//$no=0;/**/
while ($row=mysqli_fetch_row($number_of_quiz))
    {
	$no=$row[0];	
	}
//echo $no;
echo "<form action='quiz_result.php' method='post' id='quiz'>";
for ($x=1;$x <=$no;$x++){
echo "<li>";
$question=mysqli_query($cn,"SELECT Question FROM questionaire where ID=".$x);
$answerA=mysqli_query($cn,"SELECT AnswerA FROM questionaire where ID=".$x);
$answerB=mysqli_query($cn,"SELECT AnswerB FROM questionaire where ID=".$x);
$answerC=mysqli_query($cn,"SELECT AnswerC FROM questionaire where ID=".$x);
$answerD=mysqli_query($cn,"SELECT AnswerD FROM questionaire where ID=".$x);
while ($row=mysqli_fetch_row($question))
    {
	printf( "<h3>%s</h3>",$row[0]);
	}
echo "<div>";
printf("<input type='radio' name='question-%u-a' id='question-%u-answers-A' value='a'/>",$x,$x);	
while ($row=mysqli_fetch_row($answerA))
    {
printf("<label for='question-%u-answers-A'>A) %s </label>",$x,$row[0]);
		}
echo "</div>";
echo "<div>";
printf("<input type='radio' name='question-%u-a' id='question-%u-answers-B' value='b'/>",$x,$x);
while ($row=mysqli_fetch_row($answerB))
    {
printf("<label for='question-%u-answers-B'>B) %s </label>",$x,$row[0]);
		}
echo "</div>";
echo "<div>";
printf("<input type='radio' name='question-%u-a' id='question-%u-answers-C' value='c'/>",$x,$x);
while ($row=mysqli_fetch_row($answerC))
    {
printf("<label for='question-%u-answers-A'>C) %s </label>",$x,$row[0]);
		}
echo "</div>";
echo "<div>";
printf("<input type='radio' name='question-%u-a' id='question-%u-answers-D' value='d'/>",$x,$x);
while ($row=mysqli_fetch_row($answerD))
    {
printf("<label for='question-%u-answers-A'>D) %s </label>",$x,$row[0]);
		}
echo "</div>";
echo "</li>";
}
echo "<input type='submit' value='Submit Quiz'/>";
echo "</form>";
?>