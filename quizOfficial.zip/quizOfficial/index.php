<?php
$cn=mysqli_connect("localhost","root","","questionaire");
mysqli_set_charset($cn,"utf8");
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$number_of_quiz=mysqli_query($cn,"select count(ID )from questionaire");
//$no=0;/**/
while ($row=mysqli_fetch_row($number_of_quiz))
    {
	$no=$row[0];	
	}
$rs=mysqli_query($cn,"select `ID`, `Question`, `AnswerA`, `AnswerB`, `AnswerC`, `AnswerD` from `questionaire`");
echo "<form action='quiz_result.php' method='post' id='quiz'>";
$x=1;
while ($row=mysqli_fetch_row($rs))
    {
		$id=$row[0];
		$question=$row[1];
		$answerA=$row[2];
		$answerB=$row[3];
		$answerC=$row[4];
		$answerD=$row[5];
		echo "<p>Question ".$x;
		echo "<li style='list-style-type: none'>";
		echo "<p>".$question."</p>";
		echo "<div>";
		echo "<input type='radio' name='question-".$x."-a' id='question-".$x."-answers-A' value='a'/>";	
		echo "<label for='question-".$x."-answers-A'>A) ".$answerA." </label>";
		echo "</div>";
		echo "<div>";
		echo "<input type='radio' name='question-".$x."-a' id='question-".$x."-answers-B' value='b'/>";
		echo "<label for='question-".$x."-answers-B'>B) ".$answerB." </label>";
		echo "</div>";
		echo "<div>";
		echo "<input type='radio' name='question-".$x."-a' id='question-".$x."-answers-C' value='c'/>";
		echo "<label for='question-".$x."-answers-A'>C) ".$answerC." </label>";
		echo "</div>";
		echo "<div>";
		echo "<input type='radio' name='question-".$x."-a' id='question-".$x."-answers-D' value='d' required/>";
		echo "<label for='question-".$x."-answers-A'>D) ".$answerD." </label>";
		echo "</div>";
		echo "<input type='hidden' name='q".$x."' value='".$id."'/>";
		echo "</li>";
		$x++;
		}
echo "<p><input type='submit' value='Submit Quiz'/>";
echo "</form>";
mysqli_close($cn);
?>