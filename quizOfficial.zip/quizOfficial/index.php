<?php
$cn=mysqli_connect("localhost","root","","questionaire");
mysqli_set_charset($cn,"utf8");
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$number_of_quiz=mysqli_query($cn,"select count(ID )from questionaire");
//$no=0;/**/
while ($row=mysqli_fetch_row($number_of_quiz))
    {
	$no=$row[0];	
	}
$rs=mysqli_query($cn,"select `ID`, `Question`, `AnswerA`, `AnswerB`, `AnswerC`, `AnswerD` from `questionaire`");
echo "<form action='quiz_result.php' method='post' id='quiz'>";
$x=1;
while ($row=mysqli_fetch_row($rs))
    {
		$id=$row[0];
		$question=$row[1];
		$answerA=$row[2];
		$answerB=$row[3];
		$answerC=$row[4];
		$answerD=$row[5];
		echo "<p>Question ".$x;
		echo "<li style='list-style-type: none'>";
		printf( "<p>%s</p>",$question);
		echo "<div>";
		printf("<input type='radio' name='question-%u-a' id='question-%u-answers-A' value='a'/>",$x,$x);	
		printf("<label for='question-%u-answers-A'>A) %s </label>",$x,$answerA);
		echo "</div>";
		echo "<div>";
		printf("<input type='radio' name='question-%u-a' id='question-%u-answers-B' value='b'/>",$x,$x);
		printf("<label for='question-%u-answers-B'>B) %s </label>",$x,$answerB);
		echo "</div>";
		echo "<div>";
		printf("<input type='radio' name='question-%u-a' id='question-%u-answers-C' value='c'/>",$x,$x);
		printf("<label for='question-%u-answers-A'>C) %s </label>",$x,$answerC);
		echo "</div>";
		echo "<div>";
		printf("<input type='radio' name='question-%u-a' id='question-%u-answers-D' value='d'/>",$x,$x);
		printf("<label for='question-%u-answers-A'>D) %s </label>",$x,$answerD);
		echo "</div>";
		echo "<input type='hidden' name='q".$x."' value='".$id."'/>";
		echo "</li>";
		$x++;
		}
echo "<p><input type='submit' value='Submit Quiz'/>";
echo "</form>";
mysqli_close($cn);
?>