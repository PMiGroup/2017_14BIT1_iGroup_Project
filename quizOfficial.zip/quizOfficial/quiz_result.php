<?php
$cn=mysqli_connect("localhost","root","","questionaire");
mysqli_set_charset($cn,"utf8");
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$number_of_quiz=mysqli_query($cn,"select count(ID )from questionaire");
//$no=0;/**/
while ($row=mysqli_fetch_row($number_of_quiz))
    {
	$no=$row[0];	
	}
	$totalCorrect = 0;
for ($x=1;$x <=$no;$x++){
	$quizID=$_POST['q'.$x];
	//echo $quizID;
	$correct=mysqli_query($cn,"SELECT CorrectAnswer FROM questionaire where ID=".$quizID);
	$answer = $_POST['question-'.$x.'-a'];
	while ($row=mysqli_fetch_row($correct))
    {
	$correct_db=$row[0];
	}	
	echo "<p>Question ".$x.":</p><p>You chose : ".$answer."</p><p>The correct answer is : ".$correct_db."</p>";
	if ($answer == $correct_db) {	$totalCorrect++; }
}
echo "<div id='results'>" . $totalCorrect . "/ ".$no." correct</div>";
mysqli_close($cn);
?>