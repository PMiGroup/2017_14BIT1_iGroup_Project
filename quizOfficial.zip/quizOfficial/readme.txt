When entering quiz data, there has be a function that require the ID to be countinous for this php to work correctly, for example:

If there is already quiz ID continuously from 1 to 10, the next ID has to be 11 and cant be 12 or other number.

Another thing is when a quiz is deleted, the next time a quiz is entered the ID has to fill in the gap in ID that the deleted quiz left behind. Otherwise, this php will not work correctly.